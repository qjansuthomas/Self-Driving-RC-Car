### Install on raspberry pi
The easiest way to get donkey running on a pi is with 
a prebuilt disk image. To create your own disk
image you can use the scripts in /pi.


### Install on other systems
Create a conda environment using the env files in
